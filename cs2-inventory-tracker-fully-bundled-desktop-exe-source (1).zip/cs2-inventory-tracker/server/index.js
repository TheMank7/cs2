import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, '..');
const dataDir = path.join(root, 'data');
const app = express();
const PORT = process.env.PORT || 8787;

app.use(express.json({ limit: '20mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

async function readJson(file, fallback) {
  try {
    const raw = await fs.readFile(path.join(dataDir, file), 'utf8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

async function writeJson(file, value) {
  await fs.mkdir(dataDir, { recursive: true });
  await fs.writeFile(path.join(dataDir, file), JSON.stringify(value, null, 2), 'utf8');
}

function parseCurrency(value) {
  if (!value || typeof value !== 'string') return null;
  const n = Number(value.replace(/[^0-9.]/g, ''));
  return Number.isFinite(n) ? n : null;
}

async function fetchWithRetry(url, tries = 3) {
  let last;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': 'cs2-inventory-tracker/0.1' } });
      if ([429, 500, 502, 503, 504].includes(r.status)) throw new Error(`Retryable status ${r.status}`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return await r.json();
    } catch (e) {
      last = e;
      await new Promise((resolve) => setTimeout(resolve, Math.min(2 ** i, 8) * 1000));
    }
  }
  throw last;
}

app.get('/api/health', (_, res) => res.json({ ok: true, service: 'cs2-inventory-tracker' }));

app.get('/api/steam/inventory/:steamId', async (req, res) => {
  try {
    const { steamId } = req.params;
    let startAssetId = req.query.start_assetid || undefined;
    const assets = [];
    const descriptionsByKey = new Map();
    let more = true;
    let loops = 0;

    while (more && loops < 10) {
      const url = new URL(`https://steamcommunity.com/inventory/${steamId}/730/2`);
      url.searchParams.set('l', 'english');
      url.searchParams.set('count', '2000');
      if (startAssetId) url.searchParams.set('start_assetid', startAssetId);
      const data = await fetchWithRetry(url.toString(), 3);
      for (const asset of data.assets || []) assets.push(asset);
      for (const desc of data.descriptions || []) descriptionsByKey.set(`${desc.classid}:${desc.instanceid}`, desc);
      more = Boolean(data.more_items && data.last_assetid);
      startAssetId = data.last_assetid;
      loops += 1;
      if (more) await new Promise((resolve) => setTimeout(resolve, 900));
    }

    res.json({ success: 1, assets, descriptions: [...descriptionsByKey.values()], total_inventory_count: assets.length });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Failed to fetch inventory. Confirm the profile inventory is public.' });
  }
});

app.get('/api/steam/price', async (req, res) => {
  const marketHashName = String(req.query.market_hash_name || '').trim();
  if (!marketHashName) return res.status(400).json({ error: 'Missing market_hash_name' });

  const cache = await readJson('price-cache.json', {});
  const cached = cache[marketHashName];
  const maxAgeMs = 1000 * 60 * 60 * 6;
  if (cached && Date.now() - cached.fetchedAt < maxAgeMs) return res.json({ ...cached, cached: true });

  try {
    const url = new URL('https://steamcommunity.com/market/priceoverview/');
    url.searchParams.set('appid', '730');
    url.searchParams.set('currency', '1');
    url.searchParams.set('market_hash_name', marketHashName);
    const data = await fetchWithRetry(url.toString(), 3);
    const payload = {
      market_hash_name: marketHashName,
      success: data.success,
      lowest_price: data.lowest_price || null,
      median_price: data.median_price || null,
      volume: data.volume || null,
      lowest_price_num: parseCurrency(data.lowest_price),
      median_price_num: parseCurrency(data.median_price),
      source: 'steam_priceoverview',
      fetchedAt: Date.now()
    };
    cache[marketHashName] = payload;
    await writeJson('price-cache.json', cache);
    res.json(payload);
  } catch (e) {
    res.status(500).json({ error: e.message || 'Price lookup failed' });
  }
});

app.get('/api/snapshots', async (_, res) => {
  res.json(await readJson('snapshots.json', []));
});

app.post('/api/snapshots', async (req, res) => {
  const snapshots = await readJson('snapshots.json', []);
  const snapshot = { id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...req.body };
  snapshots.push(snapshot);
  await writeJson('snapshots.json', snapshots.slice(-365));
  res.json(snapshot);
});

app.listen(PORT, () => {
  console.log(`CS2 inventory tracker backend running at http://localhost:${PORT}`);
});
