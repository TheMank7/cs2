import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import { Upload, RefreshCw, Search, Save, Download, Shield, TrendingUp, AlertTriangle, Wallet, Database, Crown, Filter } from 'lucide-react';
import './styles.css';

const API_BASE = 'http://localhost:8787';
const STORAGE_KEYS = {
  items: 'cs2-tracker-items-v1',
  snapshots: 'cs2-tracker-snapshots-v1',
  steamId: 'cs2-tracker-steamid-v1',
};

function money(n) {
  if (n == null || !Number.isFinite(Number(n))) return '—';
  return Number(n).toLocaleString(undefined, { style: 'currency', currency: 'USD', maximumFractionDigits: 2 });
}

function numberish(value) {
  if (value == null || value === '') return null;
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  const parsed = Number(String(value).replace(/[^0-9.-]/g, ''));
  return Number.isFinite(parsed) ? parsed : null;
}

function joinTags(tags = []) {
  const out = {};
  for (const tag of tags || []) out[tag.category] = tag.localized_tag_name || tag.internal_name;
  return out;
}

function firstInspectTemplate(desc = {}) {
  const groups = [desc.actions || [], desc.market_actions || []];
  for (const group of groups) {
    for (const action of group) {
      if (action?.link?.includes('csgo_econ_action_preview')) return action.link;
    }
  }
  return null;
}

function buildInspectLink(template, steamId, assetId) {
  if (!template) return null;
  return template.replaceAll('%owner_steamid%', steamId || '').replaceAll('%assetid%', assetId || '');
}

function parseInventory(raw, steamId = '') {
  const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
  const descriptions = new Map();
  for (const d of data.descriptions || []) descriptions.set(`${d.classid}:${d.instanceid}`, d);

  return (data.assets || []).map((asset) => {
    const desc = descriptions.get(`${asset.classid}:${asset.instanceid}`) || {};
    const tags = joinTags(desc.tags);
    const marketName = desc.market_hash_name || desc.market_name || desc.name || 'Unknown Item';
    const inspectTemplate = firstInspectTemplate(desc);
    const inspectLink = buildInspectLink(inspectTemplate, steamId, asset.assetid);
    const isWeaponLike = Boolean(inspectTemplate) && !/Sticker|Charm|Case|Container|Music Kit|Graffiti/i.test(marketName);

    return {
      id: asset.assetid,
      assetid: asset.assetid,
      classid: asset.classid,
      instanceid: asset.instanceid,
      appid: asset.appid,
      amount: Number(asset.amount || 1),
      marketName,
      name: desc.name || marketName,
      type: desc.type || tags.Type || 'Uncategorized',
      category: tags.Weapon || tags.Type || guessCategory(marketName, desc.type),
      rarity: tags.Rarity || null,
      exterior: tags.Exterior || extractExterior(marketName),
      collection: tags.ItemSet || null,
      tradable: desc.tradable === 1,
      marketable: desc.marketable === 1,
      iconUrl: desc.icon_url ? `https://community.cloudflare.steamstatic.com/economy/image/${desc.icon_url}` : null,
      inspectLink,
      isWeaponLike,
      steamLowest: null,
      steamMedian: null,
      manualValue: null,
      floatValue: null,
      paintSeed: null,
      paintIndex: null,
      notes: '',
      lastPriceAt: null,
      priceSource: null,
    };
  });
}

function guessCategory(name, type) {
  const s = `${name || ''} ${type || ''}`;
  if (/Knife|Bayonet|Karambit|Butterfly|Talon|M9/i.test(s)) return 'Knife';
  if (/Gloves|Wraps/i.test(s)) return 'Gloves';
  if (/Sticker/i.test(s)) return 'Sticker';
  if (/Charm/i.test(s)) return 'Charm';
  if (/Case|Capsule|Package|Container/i.test(s)) return 'Container';
  if (/AK-47|M4A|AWP|Desert Eagle|USP|Glock|P250|MAC-10|MP9|FAMAS|Galil|SSG|SCAR|AUG|SG 553/i.test(s)) return 'Skin';
  return type || 'Other';
}

function extractExterior(name = '') {
  const match = name.match(/\((Factory New|Minimal Wear|Field-Tested|Well-Worn|Battle-Scarred)\)/i);
  return match ? match[1] : null;
}

function valueOfItem(item) {
  return numberish(item.manualValue) ?? numberish(item.steamLowest) ?? numberish(item.steamMedian) ?? 0;
}

function conservativeValue(item) {
  const v = valueOfItem(item);
  if (!v) return 0;
  if (/Knife|Gloves/i.test(item.category)) return v * 0.88;
  if (/Sticker|Charm|Container/i.test(item.category)) return v * 0.8;
  return v * 0.85;
}

function loadLocal(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}

function saveLocal(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function App() {
  const [items, setItems] = useState(() => loadLocal(STORAGE_KEYS.items, []));
  const [snapshots, setSnapshots] = useState(() => loadLocal(STORAGE_KEYS.snapshots, []));
  const [steamId, setSteamId] = useState(() => localStorage.getItem(STORAGE_KEYS.steamId) || '');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [sortBy, setSortBy] = useState('value');
  const [status, setStatus] = useState('Ready');
  const [isLoading, setIsLoading] = useState(false);

  const stats = useMemo(() => {
    const total = items.reduce((sum, item) => sum + valueOfItem(item), 0);
    const conservative = items.reduce((sum, item) => sum + conservativeValue(item), 0);
    const priced = items.filter((i) => valueOfItem(i) > 0).length;
    const missingPrice = items.length - priced;
    const missingFloat = items.filter((i) => i.isWeaponLike && i.floatValue == null).length;
    const tradable = items.filter((i) => i.tradable).length;
    return { total, conservative, priced, missingPrice, missingFloat, tradable };
  }, [items]);

  const categories = useMemo(() => ['All', ...Array.from(new Set(items.map((i) => i.category || 'Other'))).sort()], [items]);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return items
      .filter((item) => category === 'All' || item.category === category)
      .filter((item) => !q || `${item.marketName} ${item.type} ${item.rarity} ${item.exterior}`.toLowerCase().includes(q))
      .sort((a, b) => {
        if (sortBy === 'value') return valueOfItem(b) - valueOfItem(a);
        if (sortBy === 'name') return a.marketName.localeCompare(b.marketName);
        if (sortBy === 'category') return String(a.category).localeCompare(String(b.category));
        if (sortBy === 'float') return (numberish(a.floatValue) ?? 9) - (numberish(b.floatValue) ?? 9);
        return 0;
      });
  }, [items, query, category, sortBy]);

  const topItems = useMemo(() => [...items].sort((a,b)=>valueOfItem(b)-valueOfItem(a)).slice(0, 8), [items]);
  const categoryData = useMemo(() => {
    const buckets = new Map();
    for (const item of items) buckets.set(item.category || 'Other', (buckets.get(item.category || 'Other') || 0) + valueOfItem(item));
    return [...buckets.entries()].map(([name, value]) => ({ name, value })).sort((a,b)=>b.value-a.value).slice(0, 8);
  }, [items]);

  function commitItems(next) {
    setItems(next);
    saveLocal(STORAGE_KEYS.items, next);
  }

  function commitSnapshots(next) {
    setSnapshots(next);
    saveLocal(STORAGE_KEYS.snapshots, next);
  }

  async function handleUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      setStatus('Parsing inventory JSON...');
      const text = await file.text();
      const parsed = parseInventory(text, steamId);
      commitItems(parsed);
      setStatus(`Loaded ${parsed.length} inventory items.`);
    } catch (e) {
      setStatus(`Upload failed: ${e.message}`);
    }
  }

  async function fetchSteamInventory() {
    if (!steamId.trim()) return setStatus('Enter your SteamID64 first.');
    setIsLoading(true);
    setStatus('Fetching inventory from Steam...');
    localStorage.setItem(STORAGE_KEYS.steamId, steamId.trim());
    try {
      const r = await fetch(`${API_BASE}/api/steam/inventory/${steamId.trim()}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Steam inventory fetch failed');
      const parsed = parseInventory(data, steamId.trim());
      commitItems(parsed);
      setStatus(`Fetched and parsed ${parsed.length} items from Steam.`);
    } catch (e) {
      setStatus(`Steam fetch failed: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  }

  async function refreshPrices(limit = 25) {
    const targets = [...items]
      .filter((i) => i.marketable && i.marketName)
      .sort((a,b)=> {
        const aImportant = /Knife|Gloves|AK-47|AWP|M4A|Desert Eagle|StatTrak/i.test(a.marketName) ? 1 : 0;
        const bImportant = /Knife|Gloves|AK-47|AWP|M4A|Desert Eagle|StatTrak/i.test(b.marketName) ? 1 : 0;
        return bImportant - aImportant || valueOfItem(b) - valueOfItem(a);
      })
      .slice(0, limit);

    setIsLoading(true);
    setStatus(`Refreshing Steam prices for ${targets.length} priority items...`);
    const next = [...items];
    let updated = 0;

    for (const target of targets) {
      try {
        const r = await fetch(`${API_BASE}/api/steam/price?market_hash_name=${encodeURIComponent(target.marketName)}`);
        const data = await r.json();
        if (r.ok && data.success) {
          const idx = next.findIndex((i) => i.id === target.id);
          if (idx >= 0) {
            next[idx] = {
              ...next[idx],
              steamLowest: data.lowest_price_num,
              steamMedian: data.median_price_num,
              priceSource: data.source,
              lastPriceAt: new Date().toISOString(),
            };
            updated++;
          }
        }
      } catch {}
      commitItems([...next]);
      await new Promise((resolve) => setTimeout(resolve, 450));
    }

    setStatus(`Updated ${updated} prices. For large inventories, refresh in batches to avoid rate limits.`);
    setIsLoading(false);
  }

  function updateItem(id, patch) {
    commitItems(items.map((i) => i.id === id ? { ...i, ...patch } : i));
  }

  async function saveSnapshot() {
    const snapshot = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      itemCount: items.length,
      totalValue: stats.total,
      conservativeValue: stats.conservative,
      pricedItems: stats.priced,
      missingPrice: stats.missingPrice,
    };
    const next = [...snapshots, snapshot].slice(-365);
    commitSnapshots(next);
    try {
      await fetch(`${API_BASE}/api/snapshots`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(snapshot) });
    } catch {}
    setStatus('Snapshot saved.');
  }

  function exportCsv() {
    const cols = ['assetid','marketName','category','exterior','rarity','floatValue','paintSeed','paintIndex','steamLowest','steamMedian','manualValue','estimatedValue','tradable','marketable','inspectLink','notes'];
    const rows = [cols.join(',')].concat(items.map((item) => cols.map((key) => {
      const val = key === 'estimatedValue' ? valueOfItem(item) : item[key];
      return `"${String(val ?? '').replaceAll('"', '""')}"`;
    }).join(',')));
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cs2-inventory-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="app">
      <header className="hero">
        <div>
          <div className="eyebrow"><Shield size={16}/> Private Local Dashboard</div>
          <h1>CS2 Inventory Tracker</h1>
          <p>Upload your Steam inventory JSON or fetch your public CS2 inventory, price priority items, manually adjust rare skins, and save value snapshots over time.</p>
        </div>
        <div className="heroPanel">
          <label>SteamID64</label>
          <div className="row gap">
            <input value={steamId} onChange={(e)=>setSteamId(e.target.value)} placeholder="7656119..." />
            <button onClick={fetchSteamInventory} disabled={isLoading}><RefreshCw size={16}/> Fetch</button>
          </div>
          <small>Fetching requires your Steam inventory to be public. Uploading JSON works even if private.</small>
        </div>
      </header>

      <section className="toolbar">
        <label className="fileButton"><Upload size={16}/> Upload Inventory JSON<input type="file" accept=".json,.txt" onChange={handleUpload}/></label>
        <button onClick={() => refreshPrices(25)} disabled={!items.length || isLoading}><RefreshCw size={16}/> Refresh Top 25 Prices</button>
        <button onClick={() => refreshPrices(100)} disabled={!items.length || isLoading}><Database size={16}/> Refresh Top 100</button>
        <button onClick={saveSnapshot} disabled={!items.length}><Save size={16}/> Save Snapshot</button>
        <button onClick={exportCsv} disabled={!items.length}><Download size={16}/> Export CSV</button>
        <span className="status">{status}</span>
      </section>

      <section className="cards">
        <StatCard icon={<Wallet/>} label="Estimated Value" value={money(stats.total)} sub={`${stats.priced} priced / ${items.length} items`} />
        <StatCard icon={<TrendingUp/>} label="Conservative Cash Value" value={money(stats.conservative)} sub="Uses simple liquidity haircut" />
        <StatCard icon={<AlertTriangle/>} label="Missing Prices" value={stats.missingPrice} sub="Add manual values for rare items" />
        <StatCard icon={<Crown/>} label="Missing Floats" value={stats.missingFloat} sub="Weapon-like items only" />
      </section>

      <section className="grid2">
        <div className="panel">
          <div className="panelHeader"><h2>Value History</h2></div>
          <div className="chartBox">
            {snapshots.length ? <ResponsiveContainer width="100%" height={260}>
              <LineChart data={snapshots.map(s => ({ ...s, label: new Date(s.date).toLocaleDateString() }))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" />
                <YAxis tickFormatter={(v)=>`$${Math.round(v/1000)}k`} />
                <Tooltip formatter={(v)=>money(v)} />
                <Line type="monotone" dataKey="totalValue" strokeWidth={3} dot={false} />
                <Line type="monotone" dataKey="conservativeValue" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer> : <Empty text="Save a snapshot to start building your value chart." />}
          </div>
        </div>

        <div className="panel">
          <div className="panelHeader"><h2>Value by Category</h2></div>
          <div className="chartBox">
            {categoryData.length ? <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={categoryData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={3}>
                  {categoryData.map((_, i)=><Cell key={i}/>) }
                </Pie>
                <Tooltip formatter={(v)=>money(v)} />
              </PieChart>
            </ResponsiveContainer> : <Empty text="Price items to see category allocation." />}
          </div>
        </div>
      </section>

      <section className="panel">
        <div className="panelHeader withControls">
          <div><h2>Top Holdings</h2><p>These are the items worth reviewing manually for float, pattern, sticker craft, and liquidity adjustments.</p></div>
        </div>
        <div className="topGrid">
          {topItems.map((item) => <div className="topItem" key={item.id}>
            {item.iconUrl ? <img src={item.iconUrl} alt=""/> : <div className="placeholder"/>}
            <div>
              <strong>{item.marketName}</strong>
              <span>{item.exterior || item.category} · {money(valueOfItem(item))}</span>
            </div>
          </div>)}
          {!topItems.length && <Empty text="Upload your inventory to populate top holdings." />}
        </div>
      </section>

      <section className="panel">
        <div className="panelHeader withControls">
          <div><h2>Inventory</h2><p>Edit manual value and float fields directly. Manual value overrides Steam price.</p></div>
          <div className="controls">
            <div className="search"><Search size={16}/><input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search inventory..." /></div>
            <div className="select"><Filter size={16}/><select value={category} onChange={(e)=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select></div>
            <select value={sortBy} onChange={(e)=>setSortBy(e.target.value)}>
              <option value="value">Sort by value</option>
              <option value="name">Sort by name</option>
              <option value="category">Sort by category</option>
              <option value="float">Sort by float</option>
            </select>
          </div>
        </div>
        <div className="tableWrap">
          <table>
            <thead>
              <tr>
                <th>Item</th><th>Category</th><th>Exterior</th><th>Float</th><th>Steam</th><th>Manual</th><th>Est.</th><th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => (
                <tr key={item.id}>
                  <td className="itemCell">{item.iconUrl && <img src={item.iconUrl} alt=""/>}<div><strong>{item.marketName}</strong><small>{item.rarity || item.type}</small></div></td>
                  <td>{item.category}</td>
                  <td>{item.exterior || '—'}</td>
                  <td><input className="mini" value={item.floatValue ?? ''} onChange={(e)=>updateItem(item.id, { floatValue: e.target.value })} placeholder="0.000" /></td>
                  <td><small>{money(item.steamLowest)}</small></td>
                  <td><input className="mini" value={item.manualValue ?? ''} onChange={(e)=>updateItem(item.id, { manualValue: e.target.value })} placeholder="$" /></td>
                  <td><strong>{money(valueOfItem(item))}</strong></td>
                  <td><input value={item.notes || ''} onChange={(e)=>updateItem(item.id, { notes: e.target.value })} placeholder="pattern / sticker notes" /></td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filtered.length && <Empty text="No items match your filters yet." />}
        </div>
      </section>
    </div>
  );
}

function StatCard({ icon, label, value, sub }) {
  return <div className="card"><div className="icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div></div>;
}
function Empty({ text }) { return <div className="empty">{text}</div>; }

createRoot(document.getElementById('root')).render(<App />);
